import React from "react";
import { Slider } from "../../../../components/controls/sliders/_index";
import { useIntentBuffered } from "../../../../core/useIntentBuffered";
import { useRfxStore } from "../../../../core/rfx/Store";

function clamp01(n) {
  const v = Number(n);
  if (!Number.isFinite(v)) return 0;
  return Math.max(0, Math.min(1, v));
}
function clamp(n, a, b) {
  const v = Number(n);
  if (!Number.isFinite(v)) return a;
  return Math.max(a, Math.min(b, v));
}
function panTextFrom01(pan01) {
  const p = pan01 * 2 - 1;
  if (Math.abs(p) < 0.01) return "C";
  return p < 0 ? `L${Math.round(Math.abs(p) * 100)}` : `R${Math.round(p * 100)}`;
}

function selectTrackVol01(s, trackGuid) {
  const patch = s?.ops?.overlay?.track?.[trackGuid];
  const tm = s?.snapshot?.trackMix?.[trackGuid];
  const tr = s?.entities?.tracksByGuid?.[trackGuid];

  const vol =
    patch?.vol ?? patch?.volume ??
    tm?.vol ?? tm?.volume ??
    tr?.vol ?? tr?.volume ??
    0.8;

  return clamp01(vol);
}

function selectTrackPan01(s, trackGuid) {
  const patch = s?.ops?.overlay?.track?.[trackGuid];
  const tm = s?.snapshot?.trackMix?.[trackGuid];
  const tr = s?.entities?.tracksByGuid?.[trackGuid];

  let pan =
    patch?.pan ?? patch?.pan01 ??
    tm?.pan ?? tm?.pan01 ??
    tr?.pan ??
    0;

  const pn = Number(pan);
  const panSigned = pn >= 0 && pn <= 1 ? pn * 2 - 1 : pn; // handle 0..1 or -1..1
  return (clamp(panSigned, -1, 1) + 1) / 2;
}

export function TrackMixControls({ trackGuid }) {
  const { send, flush } = useIntentBuffered({ intervalMs: 50 });

  const truthVol01 = useRfxStore(
    React.useCallback((s) => selectTrackVol01(s, trackGuid), [trackGuid])
  );
  const truthPan01 = useRfxStore(
    React.useCallback((s) => selectTrackPan01(s, trackGuid), [trackGuid])
  );

  const isDraggingRef = React.useRef(false);
  const [liveVol01, setLiveVol01] = React.useState(truthVol01);
  const [livePan01, setLivePan01] = React.useState(truthPan01);

  React.useEffect(() => {
    if (isDraggingRef.current) return;
    setLiveVol01(truthVol01);
  }, [truthVol01, trackGuid]);

  React.useEffect(() => {
    if (isDraggingRef.current) return;
    setLivePan01(truthPan01);
  }, [truthPan01, trackGuid]);

  function endGesture() {
    if (!isDraggingRef.current) return;
    isDraggingRef.current = false;
    flush();
    setLiveVol01(truthVol01);
    setLivePan01(truthPan01);
  }

  const keyVol = `${trackGuid}:trackVol`;
  const keyPan = `${trackGuid}:trackPan`;

  return (
    <div className="flex items-center gap-2" onPointerUp={endGesture} onPointerCancel={endGesture}>
      <Slider
        label="VOL"
        min={0}
        max={1}
        step={0.01}
        value={liveVol01}
        valueText={`${Math.round(liveVol01 * 100)}%`}
        widthClass="w-[160px]"
        onChange={(v) => {
          isDraggingRef.current = true;
          const next = clamp01(v);
          setLiveVol01(next);
          send(keyVol, { name: "setTrackVolume", trackGuid, value: next });
        }}
      />

      <Slider
        label="PAN"
        min={0}
        max={1}
        step={0.01}
        value={livePan01}
        valueText={panTextFrom01(livePan01)}
        widthClass="w-[160px]"
        onChange={(v) => {
          isDraggingRef.current = true;
          const next = clamp01(v);
          setLivePan01(next);
          send(keyPan, { name: "setTrackPan", trackGuid, value: next * 2 - 1 });
        }}
      />
    </div>
  );
}