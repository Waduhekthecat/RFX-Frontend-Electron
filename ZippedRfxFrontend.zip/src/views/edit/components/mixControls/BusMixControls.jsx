// edit/components/mixControls/BusMixControls.jsx
import React from "react";
import { Slider } from "../../../../components/controls/sliders/_index";
import { useRfxStore } from "../../../../core/rfx/Store";
import { useIntentBuffered } from "../../../../core/useIntentBuffered";

function clamp01(n) {
  const v = Number(n);
  if (!Number.isFinite(v)) return 0;
  if (v < 0) return 0;
  if (v > 1) return 1;
  return v;
}

// VM truth: snapshot.busMix[busId]
// Optimistic overlay: ops.overlay.track is for tracks; so for bus we only use snapshot for now.
// (If you later add overlay.bus, we can merge it here too.)
function selectBusVol01(s, busId) {
  const bm = s?.snapshot?.busMix?.[busId] || null;

  let vol01 =
    bm?.vol ??
    bm?.volume ??
    bm?.vol01 ??
    bm?.gain ??
    0.8;

  return clamp01(vol01);
}

/**
 * BusMixControls
 * - Truth-backed from snapshot.busMix
 * - Buffered sends (or uses provided intent)
 */
export function BusMixControls({ busId, intent }) {
  const buffered = useIntentBuffered({ intervalMs: 50 });

  const truthVol01 = useRfxStore(
    React.useCallback((s) => selectBusVol01(s, busId), [busId])
  );

  const isDraggingRef = React.useRef(false);
  const [liveVol01, setLiveVol01] = React.useState(truthVol01);

  React.useEffect(() => {
    if (isDraggingRef.current) return;
    setLiveVol01(truthVol01);
  }, [truthVol01, busId]);

  function endGesture() {
    if (!isDraggingRef.current) return;
    isDraggingRef.current = false;
    buffered.flush();
    setLiveVol01(truthVol01);
  }

  const key = `${busId}:busVol`;

  return (
    <div
      className="flex items-center gap-2"
      onPointerUp={endGesture}
      onPointerCancel={endGesture}
      onPointerLeave={endGesture}
    >
      <Slider
        label="BUS"
        min={0}
        max={1}
        step={0.01}
        value={liveVol01}
        valueText={`${Math.round(liveVol01 * 100)}%`}
        widthClass="w-[160px]"
        onChange={(v) => {
          isDraggingRef.current = true;
          const next = clamp01(v);
          setLiveVol01(next);

          const payload = { name: "setBusVolume", busId, value: next };

          // If parent passed intent, use it. Otherwise use buffered sender.
          if (typeof intent === "function") intent(payload);
          else buffered.send(key, payload);
        }}
      />
    </div>
  );
}